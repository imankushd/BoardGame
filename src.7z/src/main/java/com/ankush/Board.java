package com.ankush;

public class Board {
	int[] score = new int[4];
	Dice dice = new Dice();
	String player;
}
